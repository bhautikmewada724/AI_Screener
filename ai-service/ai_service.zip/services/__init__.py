"""Service layer modules for AI pipelines."""

