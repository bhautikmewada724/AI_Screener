import test from 'node:test';
import assert from 'node:assert/strict';

import {
  buildIdempotencyKey,
  matchesTypePattern,
  resolveChannelTargets
} from '../notificationService.js';

test('matchesTypePattern supports wildcards and exact matches', () => {
  assert.equal(matchesTypePattern('project.invite', '*'), true);
  assert.equal(matchesTypePattern('project.invite', 'project.*'), true);
  assert.equal(matchesTypePattern('project.invite', 'project.invite'), true);
  assert.equal(matchesTypePattern('project.invite', 'application.*'), false);
});

test('resolveChannelTargets respects preferences and requested channels', () => {
  const prefs = [
    { typePattern: '*', inAppEnabled: true, emailEnabled: true },
    { typePattern: 'application.*', inAppEnabled: true, emailEnabled: false }
  ];

  const result = resolveChannelTargets('application.status_changed', prefs, {
    inApp: true,
    email: true
  });

  assert.equal(result.inApp, true);
  assert.equal(result.email, false);

  const requestedOff = resolveChannelTargets('application.status_changed', prefs, {
    inApp: false,
    email: true
  });
  assert.equal(requestedOff.inApp, false);
});

test('buildIdempotencyKey uses stable payload identifiers when provided', () => {
  const keyWithId = buildIdempotencyKey({
    type: 'foo.bar',
    userId: 'u1',
    payload: { entityId: 'xyz' }
  });
  assert.equal(keyWithId, 'foo.bar:u1:xyz');

  const explicit = buildIdempotencyKey({
    type: 'foo.bar',
    userId: 'u1',
    idempotencyKey: 'custom-key'
  });
  assert.equal(explicit, 'custom-key');
});




